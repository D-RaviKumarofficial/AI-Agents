---
name: motion-demo
description: Creates a 60 to 100 second motion design demo video of an AI agent or product idea in a Vox-style documentary collage (graph paper, torn tags, clippings, tape, hand-drawn marker strokes, a chat-bubble-headed AI character), with an English voice-over synced word by word, delivered as one self-contained interactive HTML player and optionally as an MP4. Use when someone asks for a demo video, an explainer, a motion design video or an animated pitch of their agent or idea.
---

# Motion demo · Vox-style explainer of an agent

You produce an animated demo of the user's agent: a voice-over script, a voice, an interactive HTML video, and an MP4 if the machine can render it. Every element enters on the word that names it.

## Inputs

1. Look for the agent design: `co-founder-project.md` (made with the Co-Founder plugin), a CLAUDE.md of the agent, a pitch, or what the user pasted.
2. Ask only for what is missing, with the interactive question tool (2 to 4 options drafted from the case). You need: agent name, user and problem, channels, mission, what it hands to a person, three test messages (normal, incomplete, out of scope) with the expected behaviour, the "never" list, the key assumption and its test, a tagline.
3. Never invent a figure, price, client name or result. What is not measured is said "to be measured" or "not claimed yet".

## Steps

1. **Project folder.** Create a folder for the video (for example `<agent>-motion/`). Every file below goes in it.
2. **Script.** Write `script.json` following `assets/example_script.json`: 8 to 12 segments, 8 to 25 words each, short sentences, one idea per segment. Story, in order: the problem (who, which channels) · the pain (repeated task, cost to be measured) · meet the agent · how it fits (inputs, other agents, what it hands over) · demo 1 normal · demo 2 incomplete (it asks, it does not guess) · demo 3 out of scope (it stops, hands over) · the person decides · never list · honesty (not claimed yet, next test) · closing tagline. Show the script to the user before the voice.
3. **Voice.**
   - With a Gemini key (environment or `.env`): `python3 scripts/voice.py <folder>`. It makes one request per segment with NO style instruction (Gemini TTS can read any instruction aloud, even a bracketed tag), rejects segments that are too long, removes clicks at segment edges, adds fades, writes `audio.wav` and `timing.json`.
   - Then `python3 scripts/check_voice.py <folder>` (strict transcription that also catches instruction words). Also transcribe the whole `audio.wav` once at the end. Regenerate any flagged segment with `python3 scripts/voice.py <folder> --regen s04` and check again.
   - Without a key: write `timing.json` yourself with estimated durations (about 2.6 words per second, 0.45 s between segments, same format as the one `voice.py` writes); the player then runs on a silent clock. Say that there is no voice.
   - Never print, copy or write an API key anywhere.
4. **Scenes.** Copy `assets/template.html` to `<folder>/video.html`. Keep the `<style>`, the player, the AI figure template and the whole `<script>`. Replace the `<section class="scene">` blocks with one scene per segment (or two segments per scene for a demo), change the `<title>`, the description and the `CH` chapter list. Follow `references/style.md` for the components and the timing syntax.
5. **Build.** `python3 scripts/build.py <folder> <name>` → `<name>.html` with fonts, voice and timing embedded (about 2 MB).
6. **Check.** Render stills at 8 to 12 key times: `node scripts/render.js <folder> <name> stills 5 14 30 …` and look at them (contact sheet if you can). Fix overlaps, text outside the frame, subtitles hiding content, elements appearing too late.
7. **MP4 (optional).** If Chrome, `puppeteer-core` and ffmpeg are available: `node scripts/render.js <folder> <name>` → `<name>.mp4` (1920x1080, 30 fps, a few minutes). Check the duration and one frame.
8. **Hand over.** Give the HTML (interactive: play, chapters, progress bar, subtitles C, full screen F, mute M) and the MP4. Say what was checked (voice transcription, stills, MP4 frames) and what was not.

## Rules

- English, short sentences, energetic documentary tone. No emojis, no stock photos, no real brand logos.
- The agent prepares, a person decides: say it in the video.
- Closing tag: "Demo v0 · fictional or early concept · nothing here is measured" (adapt if the case is real, never claim results).
- Keep the visual grammar of `references/style.md`; change the colours only if the user asks.

## Files

- `assets/template.html`: the engine (renderAt(t), player, AI figure, marker strokes, torn edges) with the Lead to Loyal example scenes.
- `assets/fonts.css`: Barlow Condensed, Bodoni Moda, Manrope, Cascadia Mono (open-licence fonts, base64).
- `assets/example_script.json`: the Lead to Loyal script, format reference.
- `references/style.md`: palette, components, entrance types, timing syntax, scene recipes.
- `scripts/voice.py`, `scripts/check_voice.py`, `scripts/build.py`, `scripts/render.js`.
