# Style guide · Vox documentary collage

## Stage and palette

- Fixed stage 1920 x 1080 (`#stage`), scaled to the window. Keep content inside x 96–1830 and y 50–940 (the subtitles sit at the bottom).
- Scenes: `<section class="scene" data-from="s05">` starts 0.25 s before segment s05 and ends when the next scene starts. Add `chap` for a navy scene (intro, "meet", closing).
- Colours: paper `#F1EDE4` · ink `#151515` · yellow `#E8DE2A` · navy `#14213D` · coral `#E0644B` (stop, never, cold) · forest `#2F5D50` (checks) · cream `#F6F3EB` (clippings).
- Type: Barlow Condensed 800 uppercase (titles, tags, stamps) · Bodoni Moda (messages, clippings) · Cascadia Mono (small kickers) · Manrope (subtitles).

## Components (all absolutely positioned with inline `left/top/width`)

| Class | Use |
|---|---|
| `.tag` (+ `.sm` `.xs` `.huge`, colours `.yellow` `.navy` `.coral` `.ink`) | Titles and labels on paper; add `data-torn="tb"` for torn top and bottom edges |
| `.clip` with `.kick` and `.hd` | Newspaper clipping: small mono kicker, condensed headline, serif text |
| `.photo` with `.cap` | Photo print with a caption (fill the top with a coloured block or a big character) |
| `.bubble` with `.kick` and `.tx` | A client message (navy); `.tx` is typed with `data-k="type"` |
| `.sheet` + `.field` (`<b>` label) + `.pill` (`.ok` `.mid` `.stop`) | What the agent prepares for the person |
| `.stamp` | Big coral stamp: STOP, NO GUESS, WE DON'T CLAIM IT YET |
| `.pp.yellow` / `.pp.coral` with `data-torn="tblr"` | Torn paper block behind the AI or a cluster |
| `.tape` (`--w`) | Masking tape on a corner |
| `.ai` with `data-pose="stand|walk|learned"` and `data-say="dots|check|q"` | The AI figure (chat bubble head) |
| `svg.mk` with `data-mk="circle|underline|arrow|check|cross"` (+ `.r` coral, `.y` yellow, `.g` green, `.w` white) | Hand-drawn marker stroke, drawn on at its time; flip an arrow with `transform:scaleY(-1)` |
| `span.hl` with `data-k="hl"` | Yellow highlighter sweeping under a word |
| `ul.lst > li` with a `svg.mk.r[data-mk=cross]` inside | A "never" list, each item crossed when spoken |

## Timing and entrances

- `data-at="s06"` (segment start) · `data-at="s06+1.2"` (seconds after) · `data-at="s06@a lead score"` (when those words are spoken, placed in proportion to their position in the segment text) · `data-at="s06@a lead score+0.3"`.
- `data-k`: `land` (pinned note dropping in) · `pop` (stamp with overshoot) · `up` / `down` / `left` / `right` (slide in) · `type` (typewriter on the `.tx` child) · `walk` (the AI walks in steps) · `hl` (highlighter) · `fade`. Marker strokes need no `data-k`.
- `data-rot="-2"`: final tilt in degrees (small, -6 to 6) for the collage feel.
- Dynamic rhythm: one new element every 0.5 to 1.5 s, the key word in the voice gets its visual, a stamp or marker on the punch line of each scene.

## Scene recipes

1. **Problem:** a huge tag ("EVERY DAY.") left, a torn yellow block right with 3–4 clippings landing one per channel named.
2. **Pain:** client bubbles sliding in, repeated tags popping ("SAME ANSWER"), a photo print of the forgotten item, a coral circle and a "COLD" tag.
3. **Meet:** navy scene, giant name tag with highlighter on the last word, the AI walking in.
4. **System:** clippings for inputs and other agents, marker arrows, the agent on a yellow block, one yellow tag per verb.
5. **Demo:** "Demo · n" ink tag, the message typed in a bubble, the sheet sliding in, fields landing on each spoken word, a pill for the score, a stamp or check on the outcome.
6. **People decide:** the AI with "PREPARES", a photo "A person", "DECIDES" yellow and "SENDS" navy.
7. **Never:** a huge "IT NEVER…" tag and a list crossed item by item.
8. **Honesty:** "?" print "To be measured", a stamp "WE DON'T CLAIM IT YET", numbered next steps.
9. **Closing:** navy, giant name, tagline tag, the Demo v0 disclaimer, the AI with a check.
