// Renders the built HTML to MP4 (1920x1080) frame by frame, or to stills for checking.
// Usage: node render.js <project_dir> <name> [fps]          -> <name>.mp4 (needs audio.wav)
//        node render.js <project_dir> <name> stills 5 12 30 -> stills/t5.jpg ...
// Needs: Google Chrome, puppeteer-core (npm i puppeteer-core in the project or globally), ffmpeg (PATH or python imageio_ffmpeg).
const path = require('path'), fs = require('fs'), { spawn, execSync } = require('child_process');
let puppeteer; try { puppeteer = require('puppeteer-core'); } catch (e) { puppeteer = require(path.join(process.argv[2], 'node_modules', 'puppeteer-core')); }
const CHROME = process.env.CHROME || ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/usr/bin/google-chrome', 'C:/Program Files/Google/Chrome/Application/chrome.exe'].find(p => fs.existsSync(p));
let FFMPEG = 'ffmpeg'; try { FFMPEG = execSync(`python3 -c "import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())"`).toString().trim(); } catch (e) {}
const [DIR, NAME, mode, ...rest] = process.argv.slice(2);
(async () => {
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new', args: ['--allow-file-access-from-files'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('PAGE ERROR:', e.message));
  await page.goto('file://' + path.join(path.resolve(DIR), NAME + '.html') + '?render=1', { waitUntil: 'load' });
  await page.waitForFunction('window.READY === true', { timeout: 60000 });
  if (mode === 'stills') {
    fs.mkdirSync(path.join(DIR, 'stills'), { recursive: true });
    for (const t of rest.map(Number)) { await page.evaluate(t => window.renderAt(t), t); await page.screenshot({ path: path.join(DIR, 'stills', `t${t}.jpg`), type: 'jpeg', quality: 80 }); }
    console.log('stills ->', path.join(DIR, 'stills')); await browser.close(); return;
  }
  const FPS = +(mode || 30), DUR = await page.evaluate(() => window.DUR), N = Math.round(DUR * FPS);
  const dst = path.join(DIR, NAME + '.partial.mp4'), final = path.join(DIR, NAME + '.mp4');
  const ff = spawn(FFMPEG, ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-',
    '-i', path.join(DIR, 'audio.wav'), '-vf', 'format=yuv420p', '-c:v', 'libx264', '-preset', 'medium', '-crf', '20',
    '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', dst], { stdio: ['pipe', 'inherit', 'inherit'] });
  for (let f = 0; f < N; f++) {
    await page.evaluate(t => window.renderAt(t), f / FPS);
    const buf = await page.screenshot({ type: 'jpeg', quality: 90, clip: { x: 0, y: 0, width: 1920, height: 1080 } });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (f % 300 === 0) console.log(`frame ${f}/${N}`);
  }
  ff.stdin.end(); await new Promise(r => ff.on('close', r));
  fs.renameSync(dst, final); console.log('done ->', final); await browser.close();
})();
