#!/usr/bin/env python3
"""Transcribes each voice segment with Gemini and flags segments with missing or extra words (for example a style tag read aloud).
Usage: python3 check_voice.py <project_dir>      -> prints OK / CHECK per segment and the ids to regenerate."""
import os, sys, json, base64, re, urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from voice import load_key

MODELS = ['gemini-3.5-flash', 'gemini-2.5-flash']
proj = os.path.abspath(sys.argv[1]); key = load_key(proj)
segs = json.load(open(os.path.join(proj, 'timing.json')))['segments']
norm = lambda s: re.sub(r"[^a-z0-9 ]", "", s.lower()).split()
bad = []
for s in segs:
    data = base64.b64encode(open(os.path.join(proj, 'voice', s['id'] + '.wav'), 'rb').read()).decode()
    body = json.dumps({"contents": [{"parts": [{"inlineData": {"mimeType": "audio/wav", "data": data}},
                                               {"text": "Transcribe EVERY word you hear in this audio, including any words at the very beginning or end that sound like instructions, tags or descriptions of a voice. Output only the words."}]}]}).encode()
    txt = ''
    for m in MODELS:
        try:
            req = urllib.request.Request(f'https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent', data=body,
                                         headers={'Content-Type': 'application/json', 'x-goog-api-key': key})
            txt = json.load(urllib.request.urlopen(req, timeout=90))['candidates'][0]['content']['parts'][0]['text'].strip(); break
        except Exception as e:
            print('  ', s['id'], m, getattr(e, 'code', e))
    extra = len(norm(txt)) - len(norm(s['text']))
    ok = txt and abs(extra) <= 2 and norm(txt)[:2] == norm(s['text'])[:2] and not re.search(r'narrat|energetic|paced|documentary|voice', txt, re.I)
    if not ok: bad.append(s['id'])
    print(s['id'], 'OK' if ok else 'CHECK', extra, '|', txt[:120])
print('to regenerate:', ' '.join(bad) or 'none')
