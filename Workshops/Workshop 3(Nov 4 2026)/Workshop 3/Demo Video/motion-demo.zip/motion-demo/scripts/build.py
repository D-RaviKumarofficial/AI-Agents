#!/usr/bin/env python3
"""Builds the self-contained interactive video: <project_dir>/<name>.html
Usage: python3 build.py <project_dir> [name]
Inputs: <project_dir>/video.html (the scenes, made from assets/template.html), timing.json, audio.wav (optional), the skill's assets/fonts.css.
Without audio.wav the page still plays in silence on the timing (useful for a draft)."""
import os, sys, json, base64, shutil, subprocess
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
proj = os.path.abspath(sys.argv[1]); name = sys.argv[2] if len(sys.argv) > 2 else 'motion_demo'


def ffmpeg():
    try:
        import imageio_ffmpeg; return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which('ffmpeg')


tpl = open(os.path.join(proj, 'video.html'), encoding='utf-8').read()
timing = json.load(open(os.path.join(proj, 'timing.json')))
audio = ''
wav = os.path.join(proj, 'audio.wav')
if os.path.exists(wav):
    ff = ffmpeg()
    if ff:
        m4a = os.path.join(proj, 'audio.m4a')
        subprocess.run([ff, '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'aac', '-b:a', '96k', m4a], check=True)
        audio = 'data:audio/mp4;base64,' + base64.b64encode(open(m4a, 'rb').read()).decode()
    else:
        audio = 'data:audio/wav;base64,' + base64.b64encode(open(wav, 'rb').read()).decode()
out = (tpl.replace('/*__FONTS__*/', open(os.path.join(SKILL, 'assets', 'fonts.css'), encoding='utf-8').read())
          .replace('/*__TIMING__*/', json.dumps(timing)).replace('__AUDIO__', audio))
dst = os.path.join(proj, name + '.html')
open(dst, 'w', encoding='utf-8').write(out)
print('written', dst, round(os.path.getsize(dst) / 1e6, 2), 'MB')
