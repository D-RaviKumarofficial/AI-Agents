#!/usr/bin/env python3
"""Voice-over with Gemini TTS, one request per segment.

Usage: python3 voice.py <project_dir> [--regen s04 s07]
Reads  <project_dir>/script.json : {"voice": "Puck", "style": "", "segments": [{"id": "s01", "text": "..."}]}
Writes <project_dir>/voice/<id>.wav, <project_dir>/audio.wav, <project_dir>/timing.json
Needs GEMINI_API_KEY in the environment (or in a .env file in the project folder or one of its parents). The key is never printed.
"""
import os, sys, json, wave, base64, time, array, urllib.request

MODELS = ['gemini-3.8-flash-tts', 'gemini-3.1-flash-tts-preview', 'gemini-2.5-flash-preview-tts']
GAP, HEAD, TAIL = 0.45, 0.6, 1.6


def load_key(start):
    if os.environ.get('GEMINI_API_KEY'): return os.environ['GEMINI_API_KEY']
    d = os.path.abspath(start)
    while True:
        p = os.path.join(d, '.env')
        if os.path.exists(p):
            for line in open(p, encoding='utf-8'):
                if line.strip().startswith('GEMINI_API_KEY') and '=' in line:
                    return line.split('=', 1)[1].strip().strip('"\'')
        if os.path.dirname(d) == d: break
        d = os.path.dirname(d)
    raise SystemExit('GEMINI_API_KEY not found (environment or .env). Use the browser voice fallback instead.')


def tts(key, text, out, voice, style):
    body = json.dumps({"contents": [{"parts": [{"text": style + text}]}],
                       "generationConfig": {"responseModalities": ["AUDIO"],
                                            "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}).encode()
    last = None
    for model in MODELS:
        for k in range(3):
            try:
                req = urllib.request.Request(f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent', data=body,
                                             headers={'Content-Type': 'application/json', 'x-goog-api-key': key})
                d = json.load(urllib.request.urlopen(req, timeout=180))
                part = d['candidates'][0]['content']['parts'][0]['inlineData']
                rate = int(part['mimeType'].split('rate=')[1].split(';')[0]) if 'rate=' in part['mimeType'] else 24000
                with wave.open(out, 'wb') as w:
                    w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(base64.b64decode(part['data']))
                return
            except Exception as e:
                last = e
                if getattr(e, 'code', None) == 404: break      # model not available: next model
                time.sleep(4 * (k + 1))
    raise RuntimeError(f'TTS failed: {getattr(last, "code", last)}')


def clean(pcm, rate):
    """Removes short clipped bursts separated from the speech by silence at the start or end, then adds 15 ms fades."""
    a = array.array('h', pcm); win = int(rate * .02); n = len(a) // win
    loud = [max(abs(x) for x in a[i * win:(i + 1) * win]) > 1500 for i in range(n)]
    runs, st = [], None
    for i, v in enumerate(loud + [False]):
        if v and st is None: st = i
        if not v and st is not None: runs.append((st, i)); st = None
    while len(runs) > 1 and runs[0][1] - runs[0][0] < 15 and runs[1][0] - runs[0][1] >= 6: runs.pop(0)
    while len(runs) > 1 and runs[-1][1] - runs[-1][0] < 15 and runs[-1][0] - runs[-2][1] >= 6: runs.pop()
    if not runs: return pcm
    a = a[max(0, runs[0][0] * win - int(rate * .05)):min(len(a), runs[-1][1] * win + int(rate * .12))]
    f = int(rate * .015)
    for i in range(min(f, len(a))): a[i] = int(a[i] * i / f); a[-1 - i] = int(a[-1 - i] * i / f)
    return a.tobytes()


def main():
    proj = os.path.abspath(sys.argv[1]); regen = sys.argv[sys.argv.index('--regen') + 1:] if '--regen' in sys.argv else []
    cfg = json.load(open(os.path.join(proj, 'script.json'), encoding='utf-8'))
    voice, style, segs = cfg.get('voice', 'Puck'), cfg.get('style', '')   # keep empty: Gemini TTS can read any instruction aloud, cfg['segments']
    key = load_key(proj); vdir = os.path.join(proj, 'voice'); os.makedirs(vdir, exist_ok=True)
    for s in segs:
        out = os.path.join(vdir, s['id'] + '.wav')
        if os.path.exists(out) and s['id'] not in regen: continue
        limit = len(s['text'].split()) * 0.45 + 1.5      # longer means the style tag was read aloud
        for k in range(4):
            print('TTS', s['id'], 'try', k + 1); tts(key, s['text'], out, voice, style)
            with wave.open(out) as w: d = w.getnframes() / w.getframerate()
            if d <= limit: break
            print('  too long', round(d, 1), '>', round(limit, 1))
        else: print('  WARNING: still too long, listen to', s['id'])
    frames, timing, rate, t = [], [], None, HEAD
    for s in segs:
        with wave.open(os.path.join(vdir, s['id'] + '.wav')) as w:
            rate = rate or w.getframerate(); pcm = clean(w.readframes(w.getnframes()), rate)
        d = len(pcm) / 2 / rate
        timing.append({'id': s['id'], 'start': round(t, 3), 'end': round(t + d, 3), 'text': s['text']}); frames.append(pcm); t += d + GAP
    sil = lambda x: b'\x00\x00' * int(rate * x)
    with wave.open(os.path.join(proj, 'audio.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(sil(HEAD) + sil(GAP).join(frames) + sil(TAIL))
    json.dump({'duration': round(t - GAP + TAIL, 3), 'segments': timing}, open(os.path.join(proj, 'timing.json'), 'w'), indent=1)
    print('audio.wav', round(t - GAP + TAIL, 1), 's')


if __name__ == '__main__': main()
