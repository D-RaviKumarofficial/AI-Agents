#!/usr/bin/env python3
"""Check the structure of an n8n workflow JSON file before import.

Usage: python3 validate_n8n.py workflow.json
Exit code 0 = no error (warnings are allowed), 1 = at least one error.
Checks the structure only. It cannot prove that n8n accepts every node:
always import the file into n8n and open it once.
"""
import json
import sys

KNOWN_TYPES = {
    "n8n-nodes-base.webhook", "n8n-nodes-base.set", "n8n-nodes-base.if", "n8n-nodes-base.wait",
    "n8n-nodes-base.noOp", "n8n-nodes-base.stickyNote", "n8n-nodes-base.code", "n8n-nodes-base.switch",
    "n8n-nodes-base.merge", "n8n-nodes-base.httpRequest", "n8n-nodes-base.scheduleTrigger",
    "n8n-nodes-base.manualTrigger", "n8n-nodes-base.respondToWebhook",
    "@n8n/n8n-nodes-langchain.agent", "@n8n/n8n-nodes-langchain.lmChatAnthropic",
    "@n8n/n8n-nodes-langchain.lmChatOpenAi",
}
CONNECTION_TYPES = {"main", "ai_languageModel", "ai_tool", "ai_memory", "ai_outputParser",
                    "ai_embedding", "ai_document", "ai_textSplitter", "ai_vectorStore", "ai_retriever"}
PLACEHOLDERS = ("AGENT NAME", "STOP_RULE_REGEX", "STOP_RULE_TRIGGERED", "SYSTEM_MESSAGE_FROM_AGENT_SHEET")


def check(path):
    errors, warnings = [], []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError) as exc:
        return ["cannot read valid JSON: %s" % exc], []

    if not isinstance(data, dict):
        return ["top level must be an object"], []
    nodes = data.get("nodes")
    connections = data.get("connections")
    if not isinstance(nodes, list) or not nodes:
        errors.append("'nodes' must be a non-empty list")
        nodes = []
    if not isinstance(connections, dict):
        errors.append("'connections' must be an object")
        connections = {}

    names, ids = set(), set()
    for i, n in enumerate(nodes):
        label = "node #%d" % (i + 1)
        if not isinstance(n, dict):
            errors.append("%s is not an object" % label)
            continue
        name = n.get("name")
        if not isinstance(name, str) or not name:
            errors.append("%s has no name" % label)
        else:
            label = "node '%s'" % name
            if name in names:
                errors.append("%s: duplicate name" % label)
            names.add(name)
        nid = n.get("id")
        if not isinstance(nid, str) or not nid:
            errors.append("%s has no id" % label)
        elif nid in ids:
            errors.append("%s: duplicate id" % label)
        else:
            ids.add(nid)
        ntype = n.get("type")
        if not isinstance(ntype, str) or not ntype:
            errors.append("%s has no type" % label)
        elif ntype not in KNOWN_TYPES:
            warnings.append("%s: type '%s' is not in the checked list, verify it exists in your n8n version" % (label, ntype))
        if not isinstance(n.get("typeVersion"), (int, float)) or isinstance(n.get("typeVersion"), bool):
            errors.append("%s: typeVersion must be a number" % label)
        pos = n.get("position")
        if not (isinstance(pos, list) and len(pos) == 2 and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in pos)):
            errors.append("%s: position must be [x, y] numbers" % label)
        if not isinstance(n.get("parameters"), dict):
            errors.append("%s: parameters must be an object" % label)
        if n.get("credentials"):
            warnings.append("%s contains credentials: remove them before sharing the file" % label)

    incoming = {}
    for src, outputs in connections.items():
        if src not in names:
            errors.append("connections: unknown source node '%s'" % src)
        if not isinstance(outputs, dict):
            errors.append("connections: '%s' must be an object" % src)
            continue
        for ctype, branches in outputs.items():
            if ctype not in CONNECTION_TYPES:
                warnings.append("connections: '%s' uses unusual connection type '%s'" % (src, ctype))
            if not isinstance(branches, list):
                errors.append("connections: '%s.%s' must be a list of lists" % (src, ctype))
                continue
            for branch in branches:
                if not isinstance(branch, list):
                    errors.append("connections: '%s.%s' must be a list of lists" % (src, ctype))
                    continue
                for link in branch:
                    target = link.get("node") if isinstance(link, dict) else None
                    if target not in names:
                        errors.append("connections: '%s' points to unknown node '%s'" % (src, target))
                    else:
                        incoming.setdefault(target, set()).add(ctype)
                    if isinstance(link, dict) and link.get("type") != ctype:
                        errors.append("connections: '%s' link to '%s' has type '%s', expected '%s'" % (src, target, link.get("type"), ctype))

    for n in nodes:
        if not isinstance(n, dict):
            continue
        if n.get("type") == "@n8n/n8n-nodes-langchain.agent" and "ai_languageModel" not in incoming.get(n.get("name"), set()):
            errors.append("agent node '%s' has no chat model connected (ai_languageModel)" % n.get("name"))

    text = json.dumps(data, ensure_ascii=False)
    for token in PLACEHOLDERS:
        if token in text:
            errors.append("placeholder '%s' is still in the file: replace it" % token)
    return errors, warnings


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    errs, warns = check(sys.argv[1])
    for w in warns:
        print("WARNING:", w)
    for e in errs:
        print("ERROR:", e)
    if errs:
        print("FAILED: %d error(s), %d warning(s)" % (len(errs), len(warns)))
        sys.exit(1)
    print("OK: structure valid, %d warning(s). Now import it in n8n and open it once." % len(warns))
