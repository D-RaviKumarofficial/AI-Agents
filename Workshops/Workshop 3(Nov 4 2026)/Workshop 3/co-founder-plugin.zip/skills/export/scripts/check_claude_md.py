#!/usr/bin/env python3
"""Check an agent CLAUDE.md before it is handed over.

Usage: python3 check_claude_md.py CLAUDE.md
Exit code 0 = no error (warnings are allowed), 1 = at least one error.
Checks the structure only: it cannot judge whether the content is right.
"""
import re
import sys

REQUIRED = ["Mission", "Rules that always apply", "Jobs, in order", "Inputs", "Approved knowledge",
            "Tools and actions", "Output format", "Journey and human checkpoints", "Never",
            "Stop and hand over when", "Tests", "Open gaps"]
SECRET_PATTERNS = [r"sk-[A-Za-z0-9]{16,}", r"api[_-]?key\s*[:=]\s*\S+", r"password\s*[:=]\s*\S+", r"Bearer\s+[A-Za-z0-9._-]{16,}"]


def check(path):
    errors, warnings = [], []
    try:
        with open(path, encoding="utf-8") as f:
            text = f.read()
    except OSError as exc:
        return ["cannot read the file: %s" % exc], []

    if not text.lstrip().startswith("# "):
        errors.append("the file must start with a level 1 title (# Agent name)")
    headings = [h.strip() for h in re.findall(r"^##\s+(.+)$", text, flags=re.M)]
    for name in REQUIRED:
        if name not in headings:
            errors.append("missing section: ## %s" % name)
    for m in re.finditer(r"\{\{[A-Z_]+\}\}", text):
        errors.append("placeholder not replaced: %s" % m.group(0))
    for pat in SECRET_PATTERNS:
        if re.search(pat, text, flags=re.I):
            errors.append("text that looks like a secret (%s): remove it" % pat)

    def section(name):
        m = re.search(r"^##\s+%s\s*$(.*?)(?=^##\s|\Z)" % re.escape(name), text, flags=re.M | re.S)
        return m.group(1) if m else ""

    never_items = [ln for ln in section("Never").splitlines() if ln.strip().startswith(("-", "*", "1", "2", "3"))]
    if len(never_items) < 2:
        errors.append("the 'Never' section needs at least two items")
    if not [ln for ln in section("Stop and hand over when").splitlines() if ln.strip().startswith(("-", "*", "1", "2", "3"))]:
        errors.append("the 'Stop and hand over when' section needs at least one item")
    test_rows = [ln for ln in section("Tests").splitlines() if ln.strip().startswith("|") and not re.match(r"^\|\s*[-: |]+\|?\s*$", ln) and "Test" not in ln.split("|")[1]]
    if len(test_rows) < 3:
        errors.append("the 'Tests' table needs three tests (normal, incomplete, out of scope)")
    if not re.search(r"never send|not send|do not send|never sends", text, flags=re.I):
        warnings.append("the file does not say that the agent never sends anything alone")
    if len(text.split()) < 150:
        warnings.append("the file is very short: check that nothing is missing")
    return errors, warnings


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    errs, warns = check(sys.argv[1])
    for w in warns:
        print("WARNING:", w)
    for e in errs:
        print("ERROR:", e)
    if errs:
        print("FAILED: %d error(s), %d warning(s)" % (len(errs), len(warns)))
        sys.exit(1)
    print("OK: structure valid, %d warning(s). Now add the real sources and run the three tests." % len(warns))
