# Co-Founder

A plugin of five guided skills that help you design a first AI agent, from a product concept to an export: a starter n8n workflow or an agent CLAUDE.md. Each skill reads what you give it, finds the gaps, and prepares **complementary questions for those gaps only** (interactive multiple-choice questions drafted from your case, not a fixed list read in the chat), challenges vague answers and produces a short result. The results build one project file, `co-founder-project.md`.

| Skill | What it does | Result |
|---|---|---|
| `/co-founder:concept` | Turns an opportunity into a product concept | Concept, user, beneficiary, who might pay, value measure, key assumption and test |
| `/co-founder:agent-sheet` | Describes one agent | Mission, inputs, approved knowledge, tools, actions, output, missing dependencies |
| `/co-founder:journey-limits` | Places people and limits | Journey, human checkpoints, "never" list, stop rule |
| `/co-founder:test-improve` | Checks the design on paper | Three tests, finding, change, recheck |
| `/co-founder:export` | Exports the design, in the route you choose | Route 1: a valid n8n workflow JSON (starter, no credentials). Route 2: a `CLAUDE.md` for the agent (mission, knowledge, limits, tests, open gaps) |

Run them in this order. You can paste a block (for example a workshop correction) as the answers: the skill only asks for what is missing.

All examples are fictional (Sandline Gifts, the agents Reach and Lead to Loyal). Nothing is measured: figures stay "to be measured". `examples/lead-to-loyal-n8n.json` and `examples/lead-to-loyal-CLAUDE.md` are structure-checked samples of the two export routes.

Both exports are starters: add your own accounts, tools and approved sources, then run the three tests before any real use.
