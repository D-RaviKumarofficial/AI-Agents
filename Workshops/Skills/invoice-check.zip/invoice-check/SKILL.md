---
name: invoice-check
description: Checks supplier invoices against our payment rules before they are paid. Use when the user uploads invoices, asks to check, verify or approve invoices, or prepares a payment run.
---

# Invoice Check

## Ask for (if missing)
- The invoices (PDF or images)
- The payment period

## Steps
1. Extract supplier, invoice number, date, amount before VAT, VAT and total.
2. Flag duplicates (same supplier and invoice number).
3. Flag a missing supplier tax registration number.
4. Check that VAT is 5% of the amount before VAT, and flag any difference.
5. Mark each invoice Ready to pay or Needs review, with the reason.

## Tools and permissions
- Read the uploaded invoices (read only)
- Write the payment-run file
- No access to the bank or the payment system

## Output
A table with one row per invoice, then a 3-line summary. For a file, use the xlsx skill.

## Human approval
A person approves every payment. The agent only marks invoices Ready to pay or Needs review.

## Rules
- Never approve payment yourself.
- Never invent missing values. Write "not found".
- Always mask bank account numbers except the last 4 digits.

## Checks before you answer
- [ ] Every invoice has a supplier, a number, a date and a total
- [ ] VAT matches 5% of the net amount
- [ ] No invoice appears twice
- [ ] Every Needs review row states a reason

## Example of a great result
See references/example.md
