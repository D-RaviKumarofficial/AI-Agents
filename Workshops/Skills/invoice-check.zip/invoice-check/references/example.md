# Example of a great result

| Supplier | Invoice | VAT | Status |
|---|---|---|---|
| Gulf Print LLC | INV-0388 | 5% | Ready to pay |
| Al Noor Trading | INV-2041 | 5% | Needs review: duplicate |
